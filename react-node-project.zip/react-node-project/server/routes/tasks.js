const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const { verifyToken, checkRole } = require('../middleware/auth');

// الحصول على جميع المهام
router.get('/', async (req, res) => {
  try {
    const { status, priority, assignedTo } = req.query;
    const filter = {};
    
    // إضافة المرشحات إذا كانت موجودة
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (assignedTo) filter.assignedTo = assignedTo;
    
    // إضافة مرشح المستخدم الحالي إذا كان طالبًا
    if (req.user.role === 'student') {
      filter.assignedTo = req.user._id;
    }
    
    const tasks = await Task.find(filter)
      .populate('createdBy', 'name email')
      .populate('assignedTo', 'name email')
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      tasks
    });
  } catch (error) {
    console.error('خطأ في جلب المهام:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء جلب المهام'
    });
  }
});

// إنشاء مهمة جديدة
router.post('/', checkRole(['admin', 'teacher']), async (req, res) => {
  try {
    const { title, description, priority, dueDate, assignedTo, project } = req.body;
    
    const task = new Task({
      title,
      description,
      priority,
      dueDate,
      assignedTo,
      project,
      createdBy: req.user._id
    });
    
    await task.save();
    
    res.status(201).json({
      success: true,
      message: 'تم إنشاء المهمة بنجاح',
      task
    });
  } catch (error) {
    console.error('خطأ في إنشاء المهمة:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء إنشاء المهمة'
    });
  }
});

// الحصول على مهمة محددة
router.get('/:id', async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate('createdBy', 'name email')
      .populate('assignedTo', 'name email')
      .populate('project', 'name');
    
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'المهمة غير موجودة'
      });
    }
    
    // التحقق من الصلاحيات
    if (req.user.role === 'student' && 
        task.assignedTo.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك صلاحية للوصول إلى هذه المهمة'
      });
    }
    
    res.json({
      success: true,
      task
    });
  } catch (error) {
    console.error('خطأ في جلب المهمة:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء جلب المهمة'
    });
  }
});

// تحديث مهمة
router.patch('/:id', async (req, res) => {
  try {
    const { title, description, status, priority, dueDate, assignedTo } = req.body;
    const taskId = req.params.id;
    
    // البحث عن المهمة
    const task = await Task.findById(taskId);
    
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'المهمة غير موجودة'
      });
    }
    
    // التحقق من الصلاحيات
    if (req.user.role === 'student') {
      // الطلاب يمكنهم فقط تحديث حالة المهام المخصصة لهم
      if (task.assignedTo.toString() !== req.user._id.toString()) {
        return res.status(403).json({
          success: false,
          message: 'ليس لديك صلاحية لتحديث هذه المهمة'
        });
      }
      
      // الطلاب يمكنهم فقط تحديث الحالة
      if (status) task.status = status;
    } else {
      // المعلمون والمسؤولون يمكنهم تحديث جميع الحقول
      if (title) task.title = title;
      if (description) task.description = description;
      if (status) task.status = status;
      if (priority) task.priority = priority;
      if (dueDate) task.dueDate = dueDate;
      if (assignedTo) task.assignedTo = assignedTo;
    }
    
    await task.save();
    
    res.json({
      success: true,
      message: 'تم تحديث المهمة بنجاح',
      task
    });
  } catch (error) {
    console.error('خطأ في تحديث المهمة:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء تحديث المهمة'
    });
  }
});

// حذف مهمة
router.delete('/:id', checkRole(['admin', 'teacher']), async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'المهمة غير موجودة'
      });
    }
    
    await task.remove();
    
    res.json({
      success: true,
      message: 'تم حذف المهمة بنجاح'
    });
  } catch (error) {
    console.error('خطأ في حذف المهمة:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء حذف المهمة'
    });
  }
});

// إضافة تعليق إلى مهمة
router.post('/:id/comments', async (req, res) => {
  try {
    const { content } = req.body;
    const taskId = req.params.id;
    
    const task = await Task.findById(taskId);
    
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'المهمة غير موجودة'
      });
    }
    
    // التحقق من الصلاحيات للطلاب
    if (req.user.role === 'student' && 
        task.assignedTo.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك صلاحية للتعليق على هذه المهمة'
      });
    }
    
    task.comments.push({
      content,
      author: req.user._id
    });
    
    await task.save();
    
    res.status(201).json({
      success: true,
      message: 'تم إضافة التعليق بنجاح',
      comment: task.comments[task.comments.length - 1]
    });
  } catch (error) {
    console.error('خطأ في إضافة تعليق:', error);
    res.status(500).json({
      success: false,
      message: 'حدث خطأ أثناء إضافة التعليق'
    });
  }
});

module.exports = router;
