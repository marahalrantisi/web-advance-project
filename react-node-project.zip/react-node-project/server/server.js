const express = require('express');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');
const http = require('http');
const socketIo = require('socket.io');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');

// تحميل متغيرات البيئة
dotenv.config();

// استيراد المسارات
const authRoutes = require('./routes/auth');
const tasksRoutes = require('./routes/tasks');
const projectsRoutes = require('./routes/projects');
const usersRoutes = require('./routes/users');
const notificationsRoutes = require('./routes/notifications');

// استيراد وسائط
const { verifyToken } = require('./middleware/auth');

// إنشاء تطبيق Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// الاتصال بقاعدة البيانات
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/task-management', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('تم الاتصال بقاعدة البيانات بنجاح'))
.catch(err => console.error('خطأ في الاتصال بقاعدة البيانات:', err));

// الإعدادات الأساسية
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// تكوين WebSocket
require('./services/websocketService')(io);

// المسارات API
app.use('/api/auth', authRoutes);
app.use('/api/tasks', verifyToken, tasksRoutes);
app.use('/api/projects', verifyToken, projectsRoutes);
app.use('/api/users', verifyToken, usersRoutes);
app.use('/api/notifications', verifyToken, notificationsRoutes);

// خدمة الملفات الثابتة للواجهة الأمامية في الإنتاج
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// معالجة الأخطاء
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'حدث خطأ في الخادم',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// تشغيل الخادم
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`الخادم يعمل على المنفذ ${PORT}`);
});

module.exports = { app, server };
