import React, { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';

// إنشاء سياق المصادقة
const AuthContext = createContext();

// مزود سياق المصادقة
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // التحقق من حالة المصادقة عند تحميل التطبيق
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const token = sessionStorage.getItem('token');
        
        if (!token) {
          setLoading(false);
          return;
        }
        
        // التحقق من صلاحية الرمز
        const response = await axios.get('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        if (response.data.user) {
          setUser(response.data.user);
        }
      } catch (err) {
        console.error('خطأ في التحقق من حالة المصادقة:', err);
        // مسح البيانات المحلية في حالة وجود خطأ
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('user');
      } finally {
        setLoading(false);
      }
    };
    
    checkAuthStatus();
  }, []);

  // تسجيل الدخول
  const login = async (credentials) => {
    try {
      setError(null);
      const response = await axios.post('/api/auth/login', credentials);
      
      if (response.data.token) {
        sessionStorage.setItem('token', response.data.token);
        sessionStorage.setItem('user', JSON.stringify(response.data.user));
        setUser(response.data.user);
        return true;
      }
    } catch (err) {
      console.error('خطأ في تسجيل الدخول:', err);
      setError(err.response?.data?.message || 'فشل تسجيل الدخول');
      return false;
    }
  };

  // تسجيل مستخدم جديد
  const register = async (userData) => {
    try {
      setError(null);
      const response = await axios.post('/api/auth/register', userData);
      
      if (response.data.token) {
        sessionStorage.setItem('token', response.data.token);
        sessionStorage.setItem('user', JSON.stringify(response.data.user));
        setUser(response.data.user);
        return true;
      }
    } catch (err) {
      console.error('خطأ في التسجيل:', err);
      setError(err.response?.data?.message || 'فشل التسجيل');
      return false;
    }
  };

  // تسجيل الخروج
  const logout = () => {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('user');
    setUser(null);
  };

  // تحديث بيانات المستخدم
  const updateUser = (updatedUser) => {
    sessionStorage.setItem('user', JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  // القيم المتاحة في السياق
  const value = {
    user,
    loading,
    error,
    login,
    register,
    logout,
    updateUser
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// دالة مساعدة لاستخدام سياق المصادقة
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('يجب استخدام useAuth داخل AuthProvider');
  }
  return context;
};

export default AuthContext;
