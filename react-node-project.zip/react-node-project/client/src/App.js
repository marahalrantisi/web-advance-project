import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// صفحات المستخدم العام
import Home from './pages/Home';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';

// صفحات لوحة التحكم
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Projects from './pages/Projects';
import Chat from './pages/Chat';
import CreateTask from './pages/CreateTask';

// صفحات الطالب
import StudentDashboard from './pages/StudentDashboard';
import StudentTasks from './pages/StudentTasks';
import StudentProjects from './pages/StudentProjects';
import StudentChat from './pages/StudentChat';
import StudentNotifications from './pages/StudentNotifications';

// مكونات الحماية
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* مسارات المستخدم العام */}
          <Route path="/" element={<Home />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          
          {/* مسارات لوحة التحكم */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
          <Route path="/dashboard/tasks" element={
            <ProtectedRoute>
              <Tasks />
            </ProtectedRoute>
          } />
          <Route path="/dashboard/tasks/create" element={
            <ProtectedRoute>
              <CreateTask />
            </ProtectedRoute>
          } />
          <Route path="/dashboard/projects" element={
            <ProtectedRoute>
              <Projects />
            </ProtectedRoute>
          } />
          <Route path="/dashboard/chat" element={
            <ProtectedRoute>
              <Chat />
            </ProtectedRoute>
          } />
          
          {/* مسارات الطالب */}
          <Route path="/student-dashboard" element={
            <ProtectedRoute role="student">
              <StudentDashboard />
            </ProtectedRoute>
          } />
          <Route path="/student-dashboard/tasks" element={
            <ProtectedRoute role="student">
              <StudentTasks />
            </ProtectedRoute>
          } />
          <Route path="/student-dashboard/projects" element={
            <ProtectedRoute role="student">
              <StudentProjects />
            </ProtectedRoute>
          } />
          <Route path="/student-dashboard/chat" element={
            <ProtectedRoute role="student">
              <StudentChat />
            </ProtectedRoute>
          } />
          <Route path="/student-dashboard/notifications" element={
            <ProtectedRoute role="student">
              <StudentNotifications />
            </ProtectedRoute>
          } />
          
          {/* مسار غير موجود */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
